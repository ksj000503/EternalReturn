// Fill out your copyright notice in the Description page of Project Settings.


#include "CharacterStatComponent.h"

// Sets default values for this component's properties
UCharacterStatComponent::UCharacterStatComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = false;

	// ...
}


void UCharacterStatComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
    Super::GetLifetimeReplicatedProps(OutLifetimeProps);

    DOREPLIFETIME(UCharacterStatComponent, Level);

    DOREPLIFETIME(UCharacterStatComponent, CurrentEXP);
    
    DOREPLIFETIME(UCharacterStatComponent, EXPToNextLevel);
    
    DOREPLIFETIME(UCharacterStatComponent, SkillAmplification);
    
    DOREPLIFETIME(UCharacterStatComponent, CooldownReduction);
    
    DOREPLIFETIME(UCharacterStatComponent, BasicAttackBonus);
    
    DOREPLIFETIME(UCharacterStatComponent, DamageReduction);
    
    DOREPLIFETIME(UCharacterStatComponent, LifeSteal);
    
    DOREPLIFETIME(UCharacterStatComponent, CriticalChance);
    
    DOREPLIFETIME(UCharacterStatComponent, CriticalDamage);
    
    DOREPLIFETIME(UCharacterStatComponent, VisionRange);
    
    DOREPLIFETIME(UCharacterStatComponent, MaxGauge);
    
    DOREPLIFETIME(UCharacterStatComponent, CurrentGauge);
    
    DOREPLIFETIME(UCharacterStatComponent, bIsEliminated);
}

void UCharacterStatComponent::AddEXP(float Amount)
{
    // ����ġ �߰��� ���� ���� �� ������

    CurrentEXP += Amount;

    if (CurrentEXP >= EXPToNextLevel)
    {
        LevelUp();
    }
}

void UCharacterStatComponent::LevelUp()
{
    // ���� �� �� ����ġ �ʱ�ȭ + �߰� ���� ó��

    if (Level >= 20) return;

    Level++;

    CurrentEXP = 0.f;

    RecalculateStats();
}

void UCharacterStatComponent::RecalculateStats()
{
    // TODO: DataTable���� ���� ��� Base ���� �о����
    // TODO: InventoryComponent���� ������ ���ʽ� �ջ�
}

void UCharacterStatComponent::OnRep_bIsEliminated()
{
    // ���߿� Ż�� ó�� ���� ���� �� ���⼭ ó��
}